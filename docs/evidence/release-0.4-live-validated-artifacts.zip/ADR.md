# ADR: Approved two-AZ AWS baseline

Terraform validation checks configuration validity only. It does not prove security, successful AWS provisioning, application functionality, or production readiness.

Extraction mode: **live_meta**

Observed revision: `71e6e8a248a9a762d0199ee8c8fb454382915b5128bbee8a7d6143e55d0a26a4`

Approved target: `1b3e2e7da0bfac2772685ab4a3408707b11eb7cc4383ff6cf27bb692dee0aaa3` at 2026-11-04T13:19:49.693197+00:00

## D-NET

Two-AZ VPC, public ALB subnets, private application subnets, isolated database subnets.

Observations: legacy_postgresql. Findings: AR-003:legacy_postgresql.

Baseline: a new IPv4 VPC in the selected AWS region; no existing network is imported.

## D-APP

Internet-facing HTTP ALB routes to at least two private ASG instances across two AZs.

Observations: api_gateway_service, document_worker, orders_service. Findings: AR-001:api_gateway_service, AR-001:document_worker, AR-001:orders_service.

Baseline: illustrative HTTP service; production TLS, application packaging, authentication, and monitoring require additional work.

## D-DB

Private encrypted Multi-AZ RDS PostgreSQL with managed credentials and seven-day backups.

Observations: api_gateway_service, customer_portal, document_worker, legacy_postgresql, orders_service, primary_postgresql. Findings: AR-003:legacy_postgresql, AR-005:api_gateway_service+legacy_postgresql+customer_portal+orders_service+document_worker+primary_postgresql, AR-006:legacy_postgresql, AR-007:legacy_postgresql+primary_postgresql.

Baseline: application-to-database access is allowed on port 5432; application integration is not provisioned.

## Component scope and accepted simplifications

This is a new illustrative baseline, not a faithful conversion or migration of the uploaded architecture. Unsupported services are not consolidated automatically. Component roles and deployment coverage differ.

- `internet_clients`: **omitted**. External clients are context; they are not provisioned.
- `application_load_balancer`: **included**. The ALB role is included as a new HTTP ALB; existing listeners, TLS and routing are not imported.
- `api_gateway_service`: **unsupported**. Independent application/worker roles are not generated. The single illustrative ASG does not implement or consolidate these services.
- `legacy_postgresql`: **unsupported**. Multiple database roles cannot be preserved by the single-RDS template. No source database or migration is selected automatically.
- `customer_portal`: **unsupported**. Independent application/worker roles are not generated. The single illustrative ASG does not implement or consolidate these services.
- `orders_service`: **unsupported**. Independent application/worker roles are not generated. The single illustrative ASG does not implement or consolidate these services.
- `document_worker`: **unsupported**. Independent application/worker roles are not generated. The single illustrative ASG does not implement or consolidate these services.
- `primary_postgresql`: **unsupported**. Multiple database roles cannot be preserved by the single-RDS template. No source database or migration is selected automatically.
- `message_queue`: **unsupported**. This component has no implementation in the fixed ALB/ASG/PostgreSQL template; it remains in the observed architecture only.
- `document_object_storage`: **unsupported**. This component has no implementation in the fixed ALB/ASG/PostgreSQL template; it remains in the observed architecture only.
- `identity_provider`: **omitted**. Service-level authentication integration and coverage are not generated. RDS-managed credentials do not implement application secrets access.
- `secrets_manager`: **omitted**. Service-level secrets manager integration and coverage are not generated. RDS-managed credentials do not implement application secrets access.
- `logs_metrics`: **omitted**. Service-level monitoring integration and coverage are not generated. RDS-managed credentials do not implement application secrets access.
- `db_backups`: **replaced**. Only seven-day backups on the new RDS are configured; the observed backup system, schedules and restore testing are not reproduced.

Scope acknowledged: True

Open questions acknowledged: True

## Open questions carried into approval

```json
[
  {
    "id": "Q-001",
    "component_ids": [],
    "question": "Redundancy of Message queue: not specified",
    "origin": "graph"
  },
  {
    "id": "Q-002",
    "component_ids": [],
    "question": "Access policy of Document object storage: not specified",
    "origin": "graph"
  },
  {
    "id": "Q-003",
    "component_ids": [],
    "question": "Coverage of Logs / metrics: not specified",
    "origin": "graph"
  },
  {
    "id": "Q-004",
    "component_ids": [],
    "question": "Consumer links for Identity provider and Secrets Manager: not shown",
    "origin": "graph"
  },
  {
    "id": "Q-005",
    "component_ids": [],
    "question": "Schedule and restore tests for DB backups: not shown",
    "origin": "graph"
  },
  {
    "id": "Q-006",
    "component_ids": [],
    "question": "Instance counts for load balancer, databases, queue, and storage: not shown",
    "origin": "graph"
  },
  {
    "id": "Q-AR-004:api_gateway_service+customer_portal+orders_service+document_worker",
    "component_ids": [
      "api_gateway_service",
      "customer_portal",
      "orders_service",
      "document_worker"
    ],
    "question": "Authentication coverage unverified: No sufficiently grounded service relationship or applicable boundary establishes authentication coverage for: api_gateway_service, customer_portal, orders_service, document_worker. A standalone control box does not establish coverage; real-world absence is not proven.",
    "origin": "review"
  },
  {
    "id": "Q-AR-005:api_gateway_service+legacy_postgresql+customer_portal+orders_service+document_worker+primary_postgresql",
    "component_ids": [
      "api_gateway_service",
      "legacy_postgresql",
      "customer_portal",
      "orders_service",
      "document_worker",
      "primary_postgresql"
    ],
    "question": "Secrets management coverage unverified: No sufficiently grounded service relationship or applicable boundary establishes secrets manager coverage for: api_gateway_service, legacy_postgresql, customer_portal, orders_service, document_worker, primary_postgresql. A standalone control box does not establish coverage; real-world absence is not proven.",
    "origin": "review"
  },
  {
    "id": "Q-AR-008:api_gateway_service+legacy_postgresql+customer_portal+orders_service+document_worker+primary_postgresql",
    "component_ids": [
      "api_gateway_service",
      "legacy_postgresql",
      "customer_portal",
      "orders_service",
      "document_worker",
      "primary_postgresql"
    ],
    "question": "Monitoring coverage unverified: No sufficiently grounded service relationship or applicable boundary establishes monitoring coverage for: api_gateway_service, legacy_postgresql, customer_portal, orders_service, document_worker, primary_postgresql. A standalone control box does not establish coverage; real-world absence is not proven.",
    "origin": "review"
  },
  {
    "id": "Q-AR-007:legacy_postgresql+primary_postgresql",
    "component_ids": [
      "legacy_postgresql",
      "primary_postgresql"
    ],
    "question": "Backup and recovery coverage unverified: No sufficiently grounded service relationship or applicable boundary establishes backup coverage for: legacy_postgresql, primary_postgresql. A standalone control box does not establish coverage; real-world absence is not proven.",
    "origin": "review"
  },
  {
    "id": "Q-AR-009:message_queue",
    "component_ids": [
      "message_queue"
    ],
    "question": "Queue resilience unverified: Queue failover annotation: unknown. Delivery guarantees, retries and dead-letter handling are not established by this schema. Diagram evidence: Box in PRIVATE VPC ZONE labeled 'Message queue Private Redundancy: not specified'",
    "origin": "review"
  },
  {
    "id": "Q-AR-010:document_object_storage",
    "component_ids": [
      "document_object_storage"
    ],
    "question": "Object storage access policy unverified: Private placement alone does not establish an access policy. Diagram evidence: Box in PRIVATE VPC ZONE labeled 'Document object storage Private Access policy: not specified'",
    "origin": "review"
  }
]
```

## Control relationships

See control-coverage.json. A shown relationship does not prove effective authentication, authorization, secret access, monitoring or recovery.

## Unresolved controls and consequences

This target does not automatically resolve every finding. Authentication, authorization, TLS, application delivery, monitoring and alerting remain unresolved. HTTP port 80 is illustrative. No NAT, VPC endpoints, instance role or application bootstrap is configured. Private instances cannot download packages or retrieve managed DB credentials without additional networking and least-privilege IAM. Supply a tested regional AMI with a service on port 8080 and `/health`. Region AZ names are a/b; account-specific availability has not been checked. No provisioning was attempted.
