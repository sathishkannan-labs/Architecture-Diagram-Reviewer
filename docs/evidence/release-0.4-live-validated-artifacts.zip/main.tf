# Decision: D-NET
resource "aws_vpc" "main" {
  cidr_block           = "10.40.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true
}
# Decision: D-NET
resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id
}


# Decision: D-NET
resource "aws_subnet" "public_a" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.40.0.0/24"
  availability_zone       = "us-east-1a"
  map_public_ip_on_launch = false
}

# Decision: D-NET
resource "aws_subnet" "public_b" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.40.1.0/24"
  availability_zone       = "us-east-1b"
  map_public_ip_on_launch = false
}



# Decision: D-NET
resource "aws_subnet" "app_a" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.40.10.0/24"
  availability_zone       = "us-east-1a"
  map_public_ip_on_launch = false
}

# Decision: D-NET
resource "aws_subnet" "app_b" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.40.11.0/24"
  availability_zone       = "us-east-1b"
  map_public_ip_on_launch = false
}



# Decision: D-NET
resource "aws_subnet" "db_a" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.40.20.0/24"
  availability_zone       = "us-east-1a"
  map_public_ip_on_launch = false
}

# Decision: D-NET
resource "aws_subnet" "db_b" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.40.21.0/24"
  availability_zone       = "us-east-1b"
  map_public_ip_on_launch = false
}


# Decision: D-NET
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id
  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.main.id
  }
}
# Decision: D-NET
resource "aws_route_table" "private" {
  vpc_id = aws_vpc.main.id
}


# Decision: D-NET
resource "aws_route_table_association" "public_a" {
  subnet_id      = aws_subnet.public_a.id
  route_table_id = aws_route_table.public.id
}

# Decision: D-NET
resource "aws_route_table_association" "public_b" {
  subnet_id      = aws_subnet.public_b.id
  route_table_id = aws_route_table.public.id
}



# Decision: D-NET
resource "aws_route_table_association" "app_a" {
  subnet_id      = aws_subnet.app_a.id
  route_table_id = aws_route_table.private.id
}

# Decision: D-NET
resource "aws_route_table_association" "app_b" {
  subnet_id      = aws_subnet.app_b.id
  route_table_id = aws_route_table.private.id
}



# Decision: D-NET
resource "aws_route_table_association" "db_a" {
  subnet_id      = aws_subnet.db_a.id
  route_table_id = aws_route_table.private.id
}

# Decision: D-NET
resource "aws_route_table_association" "db_b" {
  subnet_id      = aws_subnet.db_b.id
  route_table_id = aws_route_table.private.id
}


# Decision: D-APP
resource "aws_security_group" "alb" {
  name_prefix = "archreview-demo-alb-"
  vpc_id      = aws_vpc.main.id
  ingress {
    protocol    = "tcp"
    from_port   = 80
    to_port     = 80
    cidr_blocks = ["0.0.0.0/0"]
  }
  egress {
    protocol    = "tcp"
    from_port   = 8080
    to_port     = 8080
    cidr_blocks = [aws_subnet.app_a.cidr_block, aws_subnet.app_b.cidr_block]
  }
}
# Decision: D-APP
resource "aws_security_group" "app" {
  name_prefix = "archreview-demo-app-"
  vpc_id      = aws_vpc.main.id
  ingress {
    protocol        = "tcp"
    from_port       = 8080
    to_port         = 8080
    security_groups = [aws_security_group.alb.id]
  }
  egress {
    protocol    = "tcp"
    from_port   = 5432
    to_port     = 5432
    cidr_blocks = [aws_subnet.db_a.cidr_block, aws_subnet.db_b.cidr_block]
  }
}
# Decision: D-DB
resource "aws_security_group" "db" {
  name_prefix = "archreview-demo-db-"
  vpc_id      = aws_vpc.main.id
  ingress {
    protocol        = "tcp"
    from_port       = 5432
    to_port         = 5432
    security_groups = [aws_security_group.app.id]
  }
}
# Decision: D-APP
resource "aws_lb" "app" {
  name                       = "archreview-demo-alb"
  load_balancer_type         = "application"
  internal                   = false
  subnets                    = [aws_subnet.public_a.id, aws_subnet.public_b.id]
  security_groups            = [aws_security_group.alb.id]
  drop_invalid_header_fields = true
}
# Decision: D-APP
resource "aws_lb_target_group" "app" {
  name     = "archreview-demo-tg"
  port     = 8080
  protocol = "HTTP"
  vpc_id   = aws_vpc.main.id
  health_check {
    path = "/health"
  }
}
# Decision: D-APP
resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.app.arn
  port              = 80
  protocol          = "HTTP"
  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.app.arn
  }
}
# Decision: D-APP
resource "aws_launch_template" "app" {
  name_prefix            = "archreview-demo-"
  image_id               = var.ami_id
  instance_type          = "t3.micro"
  vpc_security_group_ids = [aws_security_group.app.id]
  metadata_options {
    http_tokens   = "required"
    http_endpoint = "enabled"
  }
  block_device_mappings {
    device_name = "/dev/xvda"
    ebs {
      encrypted   = true
      volume_size = 8
      volume_type = "gp3"
    }
  }
}
# Decision: D-APP
resource "aws_autoscaling_group" "app" {
  name_prefix         = "archreview-demo-"
  min_size            = 2
  max_size            = 4
  desired_capacity    = 2
  vpc_zone_identifier = [aws_subnet.app_a.id, aws_subnet.app_b.id]
  target_group_arns   = [aws_lb_target_group.app.arn]
  health_check_type   = "ELB"
  launch_template {
    id      = aws_launch_template.app.id
    version = "$Latest"
  }
}
# Decision: D-DB
resource "aws_db_subnet_group" "db" {
  name       = "archreview-demo-db"
  subnet_ids = [aws_subnet.db_a.id, aws_subnet.db_b.id]
}
# Decision: D-DB
resource "aws_db_instance" "postgres" {
  identifier                  = "archreview-demo-postgres"
  engine                      = "postgres"
  instance_class              = "db.t3.micro"
  allocated_storage           = 20
  storage_type                = "gp3"
  storage_encrypted           = true
  multi_az                    = true
  publicly_accessible         = false
  db_subnet_group_name        = aws_db_subnet_group.db.name
  vpc_security_group_ids      = [aws_security_group.db.id]
  username                    = "archreview"
  manage_master_user_password = true
  backup_retention_period     = 7
  deletion_protection         = true
  skip_final_snapshot         = false
  final_snapshot_identifier   = "archreview-demo-final"
}
