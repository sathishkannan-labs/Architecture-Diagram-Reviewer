terraform {
  required_version = "= 1.9.8"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "= 5.100.0"
    }
  }
}
provider "aws" {
  region = "us-east-1"
  default_tags {
    tags = {
      Project          = "archreview-demo"
      ApprovedRevision = "1b3e2e7da0bfac2772685ab4a3408707b11eb7cc4383ff6cf27bb692dee0aaa3"
    }
  }
}
