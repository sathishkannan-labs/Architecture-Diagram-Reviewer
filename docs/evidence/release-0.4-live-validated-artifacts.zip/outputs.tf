output "alb_dns_name" {
  value = aws_lb.app.dns_name
}
output "database_endpoint" {
  value = aws_db_instance.postgres.address
}
output "approved_revision" {
  value = "1b3e2e7da0bfac2772685ab4a3408707b11eb7cc4383ff6cf27bb692dee0aaa3"
}
