# Generated infrastructure — review required

Terraform validation checks configuration validity only. It does not prove security, successful AWS provisioning, application functionality, or production readiness.

See ADR.md for decisions and unresolved controls; traceability.json maps all resources. component-scope.json lists every observed component and its included/replaced/omitted/unsupported disposition. open-questions.json and control-coverage.json retain unresolved information. Read validation-report.json before using any files. No plan or apply has been run. A missing lock file means the toolchain build is unavailable; run the supplied Docker build to create a genuine provider lock file. A fabricated lock file is never substituted.
