terraform {
  required_version = "= 1.9.8"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "= 5.100.0"
    }
  }
}
provider "aws" {
  region = "us-east-1"
  default_tags {
    tags = {
      Project = "archreview-demo"
      ApprovedRevision = "f98bcfacaf5e428c8f1cb0c19b2a5bbf4502f5f70cfdc479ff04f23d0fe32e30"
    }
  }
}
