# ADR: Approved two-AZ AWS baseline

Terraform validation checks configuration validity only. It does not prove security, successful AWS provisioning, application functionality, or production readiness.

Extraction mode: **fixture**

Observed revision: `2836e45abf724b35c826d907955b610dc4fe8048e1190ec4080431fe526acd36`

Approved target: `f98bcfacaf5e428c8f1cb0c19b2a5bbf4502f5f70cfdc479ff04f23d0fe32e30` at 2026-11-03T06:05:38.744639+00:00

## D-NET

Two-AZ VPC, public ALB subnets, private application subnets, isolated database subnets.

Observations: internet, app, db. Findings: none.

Baseline: a new IPv4 VPC in the selected AWS region; no existing network is imported.

## D-APP

Internet-facing HTTP ALB routes to two private ASG instances across two AZs.

Observations: app. Findings: AR-001:app.

Baseline: illustrative HTTP service; production TLS, application packaging, authentication, and monitoring require additional work.

## D-DB

Private encrypted Multi-AZ RDS PostgreSQL with managed credentials and seven-day backups.

Observations: db. Findings: AR-005:missing-information, AR-006:db.

Baseline: application-to-database access is allowed on port 5432; application integration is not provisioned.

## Unresolved controls and consequences

This target does not automatically resolve every finding. Authentication, authorization, TLS, application delivery, monitoring and alerting remain unresolved. HTTP port 80 is illustrative. No NAT, VPC endpoints, instance role or application bootstrap is configured. Private instances cannot download packages or retrieve managed DB credentials without additional networking and least-privilege IAM. Supply a tested regional AMI with a service on port 8080 and `/health`. Region AZ names are a/b; account-specific availability has not been checked. No provisioning was attempted.
