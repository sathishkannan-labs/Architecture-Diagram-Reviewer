output "alb_dns_name" {
  value = aws_lb.app.dns_name
}
output "database_endpoint" {
  value = aws_db_instance.postgres.address
}
output "approved_revision" {
  value = "f98bcfacaf5e428c8f1cb0c19b2a5bbf4502f5f70cfdc479ff04f23d0fe32e30"
}
